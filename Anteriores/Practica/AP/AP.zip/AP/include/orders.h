#include <stdio.h>

#define LVECT 20

void printvec(int v[LVECT]){
  int i; 
  for (i=0; i<LVECT; i++)
    printf("%d\t", v[i]); 
}


void QS(int v[LVECT], int inf, int sup){
  int pivote, i, j, aux;
  i=inf;
  j=sup;
  pivote=(sup+inf)/2;
  pivote=v[pivote];
  do{
    while(v[i]<pivote)
      i++;
    while(v[j]>pivote)
      j--;
    if(i<=j){
      aux=v[i];
      v[i]=v[j];
      v[j]=aux;
      i++; 
      j--;
    }
  }while(i<=j); 
  if(inf<j) QS(v, inf, j); 
  if(i<sup) QS(v, i, sup); 
}




